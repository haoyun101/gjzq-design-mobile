#!/usr/bin/env python3
"""国金DS skill 校验脚本 v1 (v3.7.1)
用法: python3 validate.py [skill根目录]      # 校验 skill 包
      python3 validate.py --site [站点目录]  # 部署包对账模式
P0 规则违例 exit 1。"""
import re,sys,os,glob
errs=[];warn=[]
def E(m):errs.append("P0 ✗ "+m)
def W(m):warn.append("P1 ⚠ "+m)
def check_skill(root):
    sk=open(f"{root}/SKILL.md",encoding="utf-8").read()
    ver=open(f"{root}/VERSION",encoding="utf-8").read().strip()
    cl=open(f"{root}/CHANGELOG.md",encoding="utf-8").read()
    top=re.search(r'^## v([\d.]+)',cl,re.M).group(1)
    if ver!=top:E(f"版本不一致 SKILL={ver} CHANGELOG={top}")
    _bn=os.path.basename(os.path.abspath(root))
    if not re.match(r"^[A-Za-z0-9_-]+$",_bn):E(f"顶层目录名须纯ASCII〔Claude.ai上传要求〕:{_bn}")
    _vu="v"+ver.replace(".","_")
    if _vu not in _bn and ("v"+ver) not in _bn:W(f"目录名未含版本 {_vu}(建议 <name>_{_vu},便于解压后溯源)")
    for _dp,_dns,_fns in os.walk(root):
        for _n in _dns+_fns:
            if not all(ord(_c)<128 for _c in _n):E(f"非ASCII文件/目录名〔Claude.ai上传拒收〕:{_n}")
    for f in glob.glob(f"{root}/references/**/*.md",recursive=True)+glob.glob(f"{root}/assets/**/*.css",recursive=True)+glob.glob(f"{root}/assets/components/*.html"):
        s=open(f,encoding="utf-8").read();b=os.path.relpath(f,root)
        if re.search(r'CL2@71%|71%/2px(?!.*已更正)',s) and "已更正" not in s:E(f"{b}: 71% 旧值残留")
        for _m in re.finditer(r'÷\s*2',s):  # ÷2 逐处判定(v3.7.6:豁免红线表述与胶囊几何,只揪真750缩放)
            _pre=s[max(0,_m.start()-4):_m.start()]; _win=s[max(0,_m.start()-14):_m.end()+10]
            if "不" in _pre: continue                      # 「不÷2」= 750红线表述本身,豁免
            if re.search(r'高度|胶囊|半径|曾假设|已废|已更正|历史',_win): continue   # 胶囊几何(圆角=高度÷2)/历史说明(曾假设÷2已废),与现行750红线无关,豁免
            W(f"{b}: 含÷2表述(疑750缩放),核对是否违反唯一基准红线: …{_win.strip()}…")
        for tk in ["--r-xl","--r-lg"]:
            if tk+":" in s or tk+")" in s:E(f"{b}: 引用已删圆角档 {tk}(v3.7.0 删除)")
        if re.search(r'#[0-9a-fA-F]{6}',s) and "design-tokens" not in b and b.endswith(".html"):
            pass # 参考实现允许内联hex(带token注释),不卡
    for f in glob.glob(f"{root}/assets/**/*",recursive=True):
        if os.path.isfile(f) and not all(ord(c)<128 for c in os.path.basename(f)):W(f"assets 非ASCII文件名: {os.path.basename(f)}")
    # 涨跌反检查:CS1 必须红 CS2 必须绿
    tok=open(f"{root}/assets/design-tokens.css",encoding="utf-8").read()
    if not re.search(r'--CS1:\s*var\(--R6\)|--CS1:\s*#?F93838',tok,re.I):E("CS1(涨)未绑红")
    if not re.search(r'--CS2:\s*var\(--G6\)|--CS2:\s*#?05B063',tok,re.I):E("CS2(跌)未绑绿")
    # 尺寸 token「值即名」铁律:--r-N/--s-N 的 N 必须等于真源像素值;旧 t-shirt/索引名禁现
    _defs=dict(re.findall(r'--([rs]-[a-z0-9]+)\s*:\s*(\d+)px',tok))   # 'r-16'->'16'
    _deprec=re.compile(r'--r-(xs|sm|md|2xl|lg|xl)\b')                 # 圆角旧名(字母,无歧义)
    _use=re.compile(r'--([rs])-(\d+)\b')                             # 值名引用
    _ann=re.compile(r'(\d+)\s*[(（]\s*`?--([rs]-[a-z0-9]+)`?\s*[)）]|`?--([rs]-[a-z0-9]+)`?\s*[(（]\s*(\d+)\s*[)）]')
    _tbl=re.compile(r'`--([rs]-[a-z0-9]+)`\s*\|\s*(\d+)')           # 表格行 `--r-16` | 16
    for _rel in ["SKILL.md","references/foundations.md","references/components.md","assets/design-tokens.css"]:
        _fp=f"{root}/{_rel}"
        if not os.path.exists(_fp):continue
        _t=sk if _rel=="SKILL.md" else open(_fp,encoding="utf-8").read()
        for _m in _deprec.finditer(_t):E(f"{_rel}: 已废弃圆角命名 --r-{_m.group(1)}(改值名 --r-N)")
        for _m in _use.finditer(_t):                                 # --r-N/--s-N 必须有定义且 N==值
            _k=f"{_m.group(1)}-{_m.group(2)}";_v=_m.group(2)
            if _k not in _defs:E(f"{_rel}: --{_k} 未在 design-tokens 定义")
            elif _defs[_k]!=_v:E(f"{_rel}: --{_k} 名值不符(真源={_defs[_k]}px)")
        for _m in _ann.finditer(_t):                                 # 形如 N(--r-x) 的标注须与真源一致
            _n=_m.group(1) or _m.group(4);_k=_m.group(2) or _m.group(3)
            if _k in _defs and _n!=_defs[_k]:E(f"{_rel}: 尺寸标注与真源不符 --{_k}={_defs[_k]}px,文中写 {_n}")
        for _m in _tbl.finditer(_t):
            _k=_m.group(1);_n=_m.group(2)
            if _k in _defs and _n!=_defs[_k]:E(f"{_rel}: 尺寸表值与真源不符 --{_k}={_defs[_k]}px,表中写 {_n}")
    # 可靠性三层:索引/脚本存在 + 索引新鲜度
    import json as _j
    for need in ["assets/library-index.json","scripts/build-index.py","scripts/check-page.py","assets/icons/icon-palette.html"]:
        if not os.path.exists(f"{root}/{need}"):E(f"可靠性三层缺文件: {need}")
    _idx=f"{root}/assets/library-index.json"
    if os.path.exists(_idx):
        _d=_j.load(open(_idx,encoding="utf-8"))
        _ncss=len(re.findall(r'\.icon-[a-z0-9-]+:before',open(f"{root}/assets/icons/fonts/iconfont.css",encoding="utf-8").read()))
        _nidx=len(_d.get("icons",{}).get("iconfont",{}))
        if _ncss!=_nidx:E(f"library-index 过期:iconfont 类 css={_ncss} 索引={_nidx},请重跑 build-index.py")
        # 组件登记表 ↔ 索引 Cxx 一致性(防 C14 那类漏登)
        _m=re.search(r'## 组件登记表.*?(?=\n## )', sk, re.S)
        _reg=set(re.findall(r'\bC\d\d\b', _m.group(0))) if _m else set()
        _idxC=set(re.findall(r'\bC\d\d\b', " ".join(_d.get("components",{}).keys())))
        if _reg and _idxC and _reg!=_idxC:E(f"组件登记表↔索引 Cxx 不一致 SKILL={sorted(_reg)} 索引={sorted(_idxC)}")
        # 组件参考实现文件必须存在(防索引指向已删/改名的 html)
        for _ck,_cv in _d.get("components",{}).items():
            _ch=_cv.get("html")
            if _ch and not os.path.exists(f"{root}/{_ch}"):E(f"组件 {_ck} 参考实现缺失: {_ch}")
    # 参考实现 750 守卫(精准):注释文档化的尺寸 NN 若 CSS 改用 NN/2,即 375 ÷2 残留(组件本体被改坏,非 demo 文字误报)
    import glob as _g
    _resid=[]
    for _f in sorted(set(_g.glob(f"{root}/assets/components/*.html")+_g.glob(f"{root}/assets/components/**/*.html",recursive=True))):
        _txt=open(_f,encoding="utf-8").read()
        _cmt=" ".join(re.findall(r'<!--(.*?)-->',_txt,re.S))
        _doc={int(x) for x in re.findall(r'(?:高度?|宽|图标|icon)\s*(\d{2,3})',_cmt)}|{int(a) for a,b in re.findall(r'(\d{2,3})\s*[×x]\s*(\d{2,3})',_cmt)}|{int(b) for a,b in re.findall(r'(\d{2,3})\s*[×x]\s*(\d{2,3})',_cmt)}
        _css={int(x) for x in re.findall(r'(?:height|width|font-size):\s*(\d+)px',_txt)}
        # d 写成「d = a + b」的组合总值(如 整体高176=88+88)不是减半残留,跳过;真减半(如"高度88(实现44)")无此加号,仍会报
        _hit=sorted(d for d in _doc if d>=40 and d%2==0 and d not in _css and d//2 in _css
                    and not re.search(rf'{d}\s*[=＝][^。;\n]*[＋+]', _cmt))
        if _hit:_resid.append(f"{os.path.relpath(_f,root)}(注释 {','.join(map(str,_hit))} 但 CSS 用了 {','.join(str(d//2) for d in _hit)})")
    if _resid:
        E("参考实现 375 ÷2 残留(组件本体尺寸被减半):"+" / ".join(_resid)+" → 改回 750 标注值")

def check_site(root):
    pages=glob.glob(f"{root}/*.html")
    for p in pages:
        s=open(p,encoding="utf-8").read();b=os.path.basename(p)
        if not all(ord(c)<128 for c in b):E(f"页面非ASCII名 {b}")
        if re.findall(r'[\s](src|href)="assets/[^"]*\.(js|css)"',s):E(f"{b}: 真外链js/css(自包含违例)")
        if not re.search(r'v3\.\d+\.\d+',s):W(f"{b}: 未见版本徽标")
    for z in glob.glob(f"{root}/assets/*.zip"):
        import zipfile
        n=zipfile.ZipFile(z).namelist()[0]
        m1=re.search(r'v([\d.]+)\.zip',z);m2=re.search(r'v([\d.]+)',n)
        if m1 and m2 and m1.group(1)!=m2.group(1):E(f"下载包名实不符 文件名v{m1.group(1)} 内容v{m2.group(1)}")
if __name__=="__main__":
    a=sys.argv[1:]
    if a and a[0]=="--site":check_site(a[1] if len(a)>1 else ".")
    else:check_skill(a[0] if a else ".")
    for m in errs+warn:print(m)
    print(f"结果: {len(errs)} P0 / {len(warn)} P1")
    sys.exit(1 if errs else 0)
