# Page Shells · 页面骨架模板

> 状态:🚧 待填充。存放 list / detail / form 等页面的栅格骨架(HTML/CSS 模板),
> AI 生成具体页面时套用,保证布局/安全区/边距一致。

计划:base-mobile(含状态栏+导航栏+安全区的移动端外壳)、list-shell、detail-shell、form-shell。
